import { authService } from '../services/auth.js';
import { postService } from '../services/post.js';
import { likeService } from '../services/like.js';
import { commentService } from '../services/comment.js';
import { favoriteService } from '../services/favorite.js';
import { reportService, ReportTypes, ReportTypeLabels, REPORT_TYPES_ORDER } from '../services/report.js';

class PostDetailPage {
  constructor() {
    this.postId = this.getPostId();
    this.currentUser = null;
    this.isLiked = false;
    this.isSaved = false;
    this.isSubmitting = false;
    this.replyingTo = null;
    this.comments = [];
    this.scrollY = 0;

    this.postDetailLoading = document.getElementById('postDetailLoading');
    this.postDetailCard = document.getElementById('postDetailCard');

    this.detailAuthorAvatar = document.getElementById('detailAuthorAvatar');
    this.detailAuthorName = document.getElementById('detailAuthorName');
    this.detailPostTime = document.getElementById('detailPostTime');
    this.detailBadges = document.getElementById('detailBadges');
    this.detailTitle = document.getElementById('detailTitle');
    this.detailCategory = document.getElementById('detailCategory');
    this.detailTags = document.getElementById('detailTags');
    this.detailBody = document.getElementById('detailBody');
    this.detailImages = document.getElementById('detailImages');
    this.detailViews = document.getElementById('detailViews');
    this.detailFavorites = document.getElementById('detailFavorites');

    this.detailFavoriteBtn = document.getElementById('detailFavoriteBtn');

    // 操作栏按钮
    this.actionLikeBtn = document.getElementById('actionLikeBtn');
    this.actionCommentBtn = document.getElementById('actionCommentBtn');
    this.actionReportBtn = document.getElementById('actionReportBtn');
    this.actionLikeCount = document.getElementById('actionLikeCount');
    this.actionCommentCount = document.getElementById('actionCommentCount');

    this.editBtn = document.getElementById('editBtn');
    this.deleteBtn = document.getElementById('deleteBtn');
    this.backButton = document.getElementById('backButton');
    this.moreButton = document.getElementById('moreButton');

    // Bottom Sheet 元素
    this.bottomSheet = document.getElementById('bottomSheet');
    this.bottomSheetOverlay = document.getElementById('bottomSheetOverlay');
    this.bottomSheetClose = document.getElementById('bottomSheetClose');
    this.bottomSheetCommentsList = document.getElementById('bottomSheetCommentsList');
    this.bottomSheetCommentCount = document.getElementById('bottomSheetCommentCount');
    this.bottomSheetCommentInput = document.getElementById('bottomSheetCommentInput');
    this.bottomSheetCommentSubmitBtn = document.getElementById('bottomSheetCommentSubmitBtn');
    this.replyIndicator = document.getElementById('replyIndicator');
    this.replyIndicatorText = document.getElementById('replyIndicatorText');
    this.replyIndicatorCancel = document.getElementById('replyIndicatorCancel');

    this.snackbar = document.getElementById('snackbar');
    this.snackbarLabel = document.getElementById('snackbarLabel');
    this.snackbarAction = document.getElementById('snackbarAction');

    this.snackbarTimer = null;

    this.init();
  }

  getPostId() {
    const params = new URLSearchParams(window.location.search);
    return params.get('id');
  }

  async init() {
    try {
      this.bindEvents();
      await this.checkSession();
      await this.getCurrentUser();
      await this.loadPost();
      await this.loadLikes();
      await this.loadFavorites();
      await this.loadComments();
    } catch (error) {
      this.showSnackbar('加载失败');
    }
  }

  async checkSession() {
    const isLoggedIn = await authService.isLoggedIn();
    if (!isLoggedIn) {
      window.location.href = 'login.html';
      throw new Error('User not logged in');
    }
  }

  async getCurrentUser() {
    const response = await authService.getCurrentUser();
    if (response.success) {
      this.currentUser = response.data;
    }
  }

  async loadPost() {
    if (!this.postId) {
      this.postDetailLoading.style.display = 'none';
      this.showSnackbar('帖子ID无效');
      return;
    }

    const response = await postService.getPostById(this.postId);

    if (!response.success) {
      this.postDetailLoading.style.display = 'none';
      this.postDetailCard.style.display = 'block';
      this.detailTitle.textContent = '加载失败';
      this.detailBody.textContent = response.message || '无法加载帖子内容，请稍后重试';
      this.showSnackbar(response.message || '加载失败');
      return;
    }

    const post = response.data;

    this.postDetailLoading.style.display = 'none';
    this.postDetailCard.style.display = 'block';

    this.detailBadges.innerHTML = '';
    this.detailTags.innerHTML = '';
    this.detailImages.innerHTML = '';
    this.detailCategory.style.display = 'none';

    const avatarUrl = post.user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.user?.id || post.user_id}`;
    this.detailAuthorAvatar.src = avatarUrl;
    this.detailAuthorAvatar.onerror = () => {
      if (this.detailAuthorAvatar.dataset.errorHandled) return;
      this.detailAuthorAvatar.dataset.errorHandled = 'true';
      this.detailAuthorAvatar.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.user?.id || post.user_id}`;
    };
    this.detailAuthorName.textContent = post.user?.nickname || '用户';
    this.detailPostTime.textContent = this.formatTime(post.created_at);
    this.detailTitle.textContent = post.title;
    this.detailBody.textContent = post.content;
    this.detailViews.textContent = post.views_count || 0;
    this.detailFavorites.textContent = post.favorites_count || 0;

    // 同步操作栏数字
    this.actionLikeCount.textContent = post.likes_count || 0;
    this.actionCommentCount.textContent = post.comments_count || 0;

    if (post.is_pinned) {
      const badge = document.createElement('span');
      badge.className = 'post-badge pinned';
      badge.textContent = '置顶';
      this.detailBadges.appendChild(badge);
    }
    if (post.is_hot) {
      const badge = document.createElement('span');
      badge.className = 'post-badge hot';
      badge.textContent = '热门';
      this.detailBadges.appendChild(badge);
    }

    if (post.tags && post.tags.length > 0) {
      post.tags.forEach(tag => {
        const tagSpan = document.createElement('span');
        tagSpan.className = 'post-tag';
        tagSpan.textContent = `#${tag}`;
        this.detailTags.appendChild(tagSpan);
      });
    }

    await this.loadPostImages();

    if (this.currentUser && this.currentUser.id === post.user_id) {
      this.editBtn.style.display = 'flex';
      this.deleteBtn.style.display = 'flex';
    }

    postService.incrementViews(this.postId);
  }

  async loadPostImages() {
    const response = await postService.getPostImages(this.postId);
    if (response.success && response.data && response.data.length > 0) {
      this.renderImages(response.data);
    }
  }

  renderImages(images) {
    if (!this.detailImages) return;

    this.detailImages.innerHTML = '';

    images.forEach((image, index) => {
      const renderUrl = image.image_url || image.url;
      if (renderUrl) {
        const img = document.createElement('img');
        img.src = renderUrl;
        img.className = 'detail-image';
        img.alt = `帖子图片${index + 1}`;
        img.onerror = () => {
          img.style.display = 'none';
        };
        this.detailImages.appendChild(img);
      }
    });
  }

  async loadLikes() {
    const response = await likeService.isLiked(this.postId);
    if (response.success) {
      this.isLiked = response.data;
      this.updateLikeButton();
    }
  }

  async loadFavorites() {
    const response = await favoriteService.isSaved(this.postId);
    if (response.success) {
      this.isSaved = response.data;
      this.updateFavoriteButton();
    }
  }

  async loadComments() {
    const response = await commentService.getComments(this.postId);
    if (response.success) {
      this.comments = response.data.comments || [];
      this.renderComments();
    } else {
      this.comments = [];
      this.renderComments();
    }
  }

  renderComments() {
    const container = this.bottomSheetCommentsList;
    container.innerHTML = '';

    const count = this.comments.length;
    const totalCount = this.countAllComments(this.comments);
    this.bottomSheetCommentCount.textContent = `${totalCount} 条评论`;
    this.actionCommentCount.textContent = totalCount;

    if (!this.comments || this.comments.length === 0) {
      container.innerHTML = '<p class="no-data" style="text-align:center;padding:2rem 0;color:var(--md-sys-color-on-surface-variant);">暂无评论，快来发表第一条吧</p>';
      return;
    }

    this.comments.forEach(comment => {
      const commentCard = this.createCommentElement(comment);
      container.appendChild(commentCard);
    });
  }

  countAllComments(comments) {
    let count = 0;
    comments.forEach(c => {
      count++;
      if (c.replies && c.replies.length > 0) {
        count += c.replies.length;
      }
    });
    return count;
  }

  createCommentElement(comment, isReply = false) {
    const commentCard = document.createElement('div');
    commentCard.className = isReply ? 'comment-card reply-card' : 'comment-card';
    commentCard.dataset.commentId = comment.id;

    const avatarUrl = comment.user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${comment.user?.id || comment.user_id}`;

    const commentHeader = document.createElement('div');
    commentHeader.className = 'comment-header';
    commentHeader.innerHTML = `
      <img src="${avatarUrl}" class="comment-avatar" alt="${comment.user?.nickname || '用户'}">
      <div class="comment-author-info">
        <span class="comment-author">${comment.user?.nickname || '用户'}</span>
        <span class="comment-time">${this.formatTime(comment.created_at)}</span>
      </div>
    `;

    const commentContent = document.createElement('div');
    commentContent.className = 'comment-content';
    commentContent.textContent = comment.content;

    const commentActions = document.createElement('div');
    commentActions.className = 'comment-actions';
    commentActions.innerHTML = `
      <button class="comment-action-btn reply-btn" data-comment-id="${comment.id}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
        </svg>
        <span>回复</span>
      </button>
    `;

    const replyBtn = commentActions.querySelector('.reply-btn');
    if (replyBtn) {
      replyBtn.addEventListener('click', () => this.handleReplyClick(comment.id, comment.user?.nickname || '用户'));
    }

    commentCard.appendChild(commentHeader);
    commentCard.appendChild(commentContent);
    commentCard.appendChild(commentActions);

    if (comment.replies && comment.replies.length > 0) {
      const repliesList = document.createElement('div');
      repliesList.className = 'replies-list';
      comment.replies.forEach(reply => {
        const replyElement = this.createCommentElement(reply, true);
        repliesList.appendChild(replyElement);
      });
      commentCard.appendChild(repliesList);
    }

    return commentCard;
  }

  handleReplyClick(commentId, nickname) {
    if (this.replyingTo === commentId) {
      this.cancelReply();
      return;
    }

    this.replyingTo = commentId;
    this.replyIndicator.style.display = 'flex';
    this.replyIndicatorText.textContent = `回复 ${nickname}`;
    this.bottomSheetCommentInput.placeholder = `回复 ${nickname}...`;
    this.bottomSheetCommentInput.focus();
  }

  cancelReply() {
    this.replyingTo = null;
    this.replyIndicator.style.display = 'none';
    this.replyIndicatorText.textContent = '';
    this.bottomSheetCommentInput.placeholder = '写下你的评论...';
  }

  async handleCommentSubmit() {
    const content = this.bottomSheetCommentInput.value.trim();
    if (!content) {
      this.showSnackbar('请输入评论内容');
      return;
    }

    if (this.isSubmitting) {
      return;
    }

    this.isSubmitting = true;
    this.bottomSheetCommentSubmitBtn.disabled = true;

    try {
      const response = await commentService.createComment(this.postId, content, this.replyingTo);
      if (response.success) {
        this.bottomSheetCommentInput.value = '';
        this.cancelReply();
        await this.loadComments();
        await this.updateCommentCount();
        this.showSnackbar(this.replyingTo ? '回复发表成功' : '评论发表成功');
      } else {
        this.showSnackbar(response.message || '提交失败');
      }
    } catch (error) {
      this.showSnackbar('提交失败，请稍后重试');
    } finally {
      this.isSubmitting = false;
      this.bottomSheetCommentSubmitBtn.disabled = false;
    }
  }

  // Bottom Sheet
  openBottomSheet() {
    this.scrollY = window.scrollY;
    document.body.style.top = `-${this.scrollY}px`;
    this.bottomSheetOverlay.classList.add('active');
    this.bottomSheet.classList.add('active');
    document.body.classList.add('sheet-open');

    setTimeout(() => {
      this.bottomSheetCommentInput.focus();
    }, 350);
  }

  closeBottomSheet() {
    this.bottomSheetOverlay.classList.remove('active');
    this.bottomSheet.classList.remove('active');
    document.body.classList.remove('sheet-open');
    document.body.style.top = '';
    this.cancelReply();

    window.scrollTo(0, this.scrollY);
  }

  formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;

    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}天前`;
    return `${date.getMonth() + 1}月${date.getDate()}日`;
  }

  async handleLike() {
    if (this.isLiking) return;
    this.isLiking = true;

    try {
      const response = await likeService.toggleLike(this.postId);
      if (response.success) {
        this.isLiked = response.data.liked;
        this.updateLikeButton();
        this.updateLikeCount();
        this.showSnackbar(response.message);
      } else {
        this.showSnackbar(response.message);
      }
    } catch (error) {
      this.showSnackbar('操作失败，请稍后重试');
    } finally {
      this.isLiking = false;
    }
  }

  updateLikeButton() {
    if (this.actionLikeBtn) {
      if (this.isLiked) {
        this.actionLikeBtn.classList.add('liked');
      } else {
        this.actionLikeBtn.classList.remove('liked');
      }
    }
  }

  async updateLikeCount() {
    const response = await likeService.getLikeCount(this.postId);
    if (response.success) {
      this.actionLikeCount.textContent = response.data;
    }
  }

  async handleFavorite() {
    if (this.isFavoriting) return;
    this.isFavoriting = true;

    try {
      const response = await favoriteService.toggleFavorite(this.postId);
      if (response.success) {
        this.isSaved = response.data.saved;
        this.updateFavoriteButton();
        this.updateFavoriteCount();
        this.showSnackbar(response.message);
      } else {
        this.showSnackbar(response.message);
      }
    } catch (error) {
      this.showSnackbar('操作失败，请稍后重试');
    } finally {
      this.isFavoriting = false;
    }
  }

  updateFavoriteButton() {
    if (this.detailFavoriteBtn) {
      if (this.isSaved) {
        this.detailFavoriteBtn.classList.add('saved');
      } else {
        this.detailFavoriteBtn.classList.remove('saved');
      }
    }
  }

  async updateFavoriteCount() {
    const response = await favoriteService.getFavoriteCount(this.postId);
    if (response.success) {
      this.detailFavorites.textContent = response.data;
    }
  }

  async updateCommentCount() {
    const response = await commentService.getCommentCount(this.postId);
    if (response.success) {
      const count = response.data;
      this.actionCommentCount.textContent = count;
      this.bottomSheetCommentCount.textContent = `${count} 条评论`;
    }
  }

  async handleDelete() {
    if (!confirm('确定要删除这篇帖子吗？')) return;

    try {
      const response = await postService.deletePost(this.postId);
      if (response.success) {
        this.showSnackbar('帖子已删除');
        setTimeout(() => {
          window.location.href = 'home.html';
        }, 1500);
      } else {
        this.showSnackbar(response.message);
      }
    } catch (error) {
      this.showSnackbar('删除失败，请稍后重试');
    }
  }

  handleEdit() {
    window.location.href = `post.html?id=${this.postId}`;
  }

  handleReport() {
    this.showReportModal();
  }

  showReportModal() {
    const existingModal = document.querySelector('.report-modal');
    if (existingModal) {
      existingModal.remove();
    }

    const modal = document.createElement('div');
    modal.className = 'report-modal';
    modal.innerHTML = `
      <div class="report-modal-overlay"></div>
      <div class="report-modal-content">
        <div class="report-modal-header">
          <h3>举报帖子</h3>
          <button class="report-modal-close">&times;</button>
        </div>
        <div class="report-modal-body">
          <div class="report-type-group">
            <label>举报类型</label>
            <div class="report-type-options">
              ${REPORT_TYPES_ORDER.map(type => `
                <label class="report-type-option">
                  <input type="radio" name="reportType" value="${type}">
                  <span>${ReportTypeLabels[type]}</span>
                </label>
              `).join('')}
            </div>
          </div>
          <div class="report-content-group">
            <label for="reportContent" id="reportContentLabel">补充说明（选填）</label>
            <textarea id="reportContent" placeholder="请说明举报原因..." rows="4"></textarea>
          </div>
        </div>
        <div class="report-modal-footer">
          <button class="report-cancel-btn">取消</button>
          <button class="report-submit-btn">提交举报</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    const closeBtn = modal.querySelector('.report-modal-close');
    const overlay = modal.querySelector('.report-modal-overlay');
    const cancelBtn = modal.querySelector('.report-cancel-btn');
    const submitBtn = modal.querySelector('.report-submit-btn');
    const contentInput = modal.querySelector('#reportContent');
    const contentLabel = modal.querySelector('#reportContentLabel');
    const radioInputs = modal.querySelectorAll('input[name="reportType"]');

    const closeModal = () => modal.remove();

    closeBtn.addEventListener('click', closeModal);
    overlay.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    radioInputs.forEach(radio => {
      radio.addEventListener('change', () => {
        if (radio.value === ReportTypes.OTHER) {
          contentLabel.textContent = '补充说明（必填）';
          contentInput.placeholder = '选择「其他」时，请务必填写补充说明...';
        } else {
          contentLabel.textContent = '补充说明（选填）';
          contentInput.placeholder = '请说明举报原因...';
        }
      });
    });

    submitBtn.addEventListener('click', async () => {
      const selectedRadio = modal.querySelector('input[name="reportType"]:checked');

      if (!selectedRadio) {
        this.showSnackbar('请选择举报类型');
        return;
      }

      const selectedType = selectedRadio.value;
      const content = contentInput.value.trim();

      if (selectedType === ReportTypes.OTHER && !content) {
        this.showSnackbar('选择「其他」时，请填写补充说明');
        contentInput.focus();
        return;
      }

      if (this.isSubmitting) {
        return;
      }

      this.isSubmitting = true;
      submitBtn.disabled = true;
      submitBtn.textContent = '提交中...';

      try {
        const response = await reportService.createReport(
          'post',
          this.postId,
          selectedType,
          content
        );

        if (response.success) {
          this.showSnackbar('举报提交成功，我们会尽快处理');
          closeModal();
        } else {
          this.showSnackbar(response.message || '举报失败');
          submitBtn.disabled = false;
          submitBtn.textContent = '提交举报';
        }
      } catch (error) {
        this.showSnackbar('举报失败，请稍后重试');
        submitBtn.disabled = false;
        submitBtn.textContent = '提交举报';
      } finally {
        this.isSubmitting = false;
      }
    });
  }

  bindEvents() {
    this.backButton.addEventListener('click', () => this.goBack());
    this.editBtn.addEventListener('click', () => this.handleEdit());
    this.deleteBtn.addEventListener('click', () => this.handleDelete());
    this.moreButton.addEventListener('click', () => this.showSnackbar('更多功能开发中'));
    this.snackbarAction.addEventListener('click', () => this.hideSnackbar());

    if (this.actionLikeBtn) {
      this.actionLikeBtn.addEventListener('click', () => this.handleLike());
    }

    if (this.detailFavoriteBtn) {
      this.detailFavoriteBtn.addEventListener('click', () => this.handleFavorite());
    }

    if (this.actionCommentBtn) {
      this.actionCommentBtn.addEventListener('click', () => this.openBottomSheet());
    }

    if (this.actionReportBtn) {
      this.actionReportBtn.addEventListener('click', () => this.handleReport());
    }

    if (this.bottomSheetClose) {
      this.bottomSheetClose.addEventListener('click', () => this.closeBottomSheet());
    }

    if (this.bottomSheetOverlay) {
      this.bottomSheetOverlay.addEventListener('click', () => this.closeBottomSheet());
    }

    if (this.bottomSheetCommentSubmitBtn) {
      this.bottomSheetCommentSubmitBtn.addEventListener('click', () => this.handleCommentSubmit());
    }

    if (this.bottomSheetCommentInput) {
      this.bottomSheetCommentInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.handleCommentSubmit();
        }
      });
    }

    if (this.replyIndicatorCancel) {
      this.replyIndicatorCancel.addEventListener('click', () => this.cancelReply());
    }

    // 向下滑动关闭 Bottom Sheet
    let startY = 0;
    let currentY = 0;

    if (this.bottomSheet) {
      this.bottomSheet.addEventListener('touchstart', (e) => {
        startY = e.touches[0].clientY;
      }, { passive: true });

      this.bottomSheet.addEventListener('touchmove', (e) => {
        currentY = e.touches[0].clientY;
        const diff = currentY - startY;

        // 只有在滚动到顶部时才允许下拉关闭
        const content = this.bottomSheet.querySelector('.bottom-sheet-content');
        if (content && content.scrollTop <= 0 && diff > 0) {
          e.preventDefault();
          this.bottomSheet.style.transform = `translateY(${diff}px)`;
        }
      }, { passive: false });

      this.bottomSheet.addEventListener('touchend', () => {
        const diff = currentY - startY;
        this.bottomSheet.style.transform = '';

        if (diff > 100) {
          this.closeBottomSheet();
        }
      });
    }
  }

  showSnackbar(message) {
    if (this.snackbarTimer) {
      clearTimeout(this.snackbarTimer);
    }
    this.snackbarLabel.textContent = message;
    this.snackbar.classList.add('show');
    this.snackbarTimer = setTimeout(() => this.hideSnackbar(), 5000);
  }

  hideSnackbar() {
    this.snackbar.classList.remove('show');
  }

  goBack() {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = 'home.html';
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new PostDetailPage();
});
